import React from 'react';
import StoreCard from './StoreCard';
import stores from '../mock/stores';

const StoreList = () => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 p-4">
      {stores.map(store => (
        <StoreCard key={store.id} store={store} />
      ))}
    </div>
  );
};

export default StoreList;