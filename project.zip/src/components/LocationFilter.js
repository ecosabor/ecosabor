import React, { useState } from 'react';

const LocationFilter = () => {
  const [range, setRange] = useState(5);

  return (
    <div className="bg-white p-4 shadow-md rounded-lg mb-6">
      <h3 className="font-bold text-lg mb-3">Filtrar por distancia</h3>
      <div className="flex items-center">
        <input
          type="range"
          min="1"
          max="20"
          value={range}
          onChange={(e) => setRange(e.target.value)}
          className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
        />
        <span className="ml-3 font-medium">{range} km</span>
      </div>
    </div>
  );
};

export default LocationFilter;