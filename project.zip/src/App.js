import React from 'react';
import AppHeader from './components/AppHeader';
import SearchBar from './components/SearchBar';
import LocationFilter from './components/LocationFilter';
import StoreList from './components/StoreList';

const App = () => {
  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      <AppHeader />
      <main className="container mx-auto px-4 pt-6">
        <SearchBar />
        <LocationFilter />
        <StoreList />
      </main>
    </div>
  );
};

export default App;

// DONE