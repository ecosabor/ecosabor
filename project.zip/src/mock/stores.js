const stores = [
  {
    id: 1,
    name: "La Tiendita de Don Pancho",
    image: "https://images.unsplash.com/photo-1604719312566-8912e9227c6a",
    discount: "30% en lácteos",
    price: "50",
    originalPrice: "70",
    location: { lat: 19.4326, lng: -99.1332 },
    address: "Av. Juárez 123, Centro",
    expiryDate: "15/08/2023",
    discountReason: "Próximo a vencer"
  },
  {
    id: 2,
    name: "ElectroHogar Plus",
    image: "https://images.unsplash.com/photo-1556740738-b6a63e27c4df",
    discount: "50% en TVs",
    price: "5000",
    originalPrice: "10000",
    location: { lat: 19.4352, lng: -99.1315 },
    address: "Paseo de la Reforma 500",
    expiryDate: "N/A",
    discountReason: "Embalaje dañado"
  }
];

export default stores;